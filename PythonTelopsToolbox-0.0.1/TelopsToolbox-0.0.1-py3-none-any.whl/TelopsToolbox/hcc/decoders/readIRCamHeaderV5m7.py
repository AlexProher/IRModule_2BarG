from TelopsToolbox.hcc.decoders.decoder import decoder


def read_ircam_header_v5m7(bytes_input):
    """
    Decode header portion of IRCam images

        header = read_ircam_header_v5m7(bytes_input)

        INPUT
            bytes_input: an array of headers in uint8 (byte) format <Nframes x Nbytes>

        OOUTPUT
            h_ini      : an array of header structures <Nframes x 1>

        *** Auto-generated function for header decoding
        *** Based on xml file definition version 5.7.2.

        DO NOT MANUALLY MODIFY THIS CODE!
        Modify the generateHeaderReaderFromXML.m script instead.
    """

    # Initialisation

    # définition de la position initiale
    ptr = 0

    # Décodage

    # attribution d'un vecteur de valeurs pour chaque champ
    h_ini = {"Identification": 0}
    h_ini["Identification"], ptr = decoder(bytes_input, 'c2', ptr)
    h_ini["DeviceXMLMinorVersion"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["DeviceXMLMajorVersion"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["ImageHeaderLength"], ptr = decoder(bytes_input, 'H', ptr)
    h_ini["ImageGating"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["EHDRIExposureIndex"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["CalibrationMode"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["BPREnabled"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["SpectralFilterWheelPosition"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["NDFilterPosition"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["CalibratedDataOffset"], ptr = decoder(bytes_input, 'f', ptr)
    h_ini["CalibratedDataLSBValue"], ptr = decoder(bytes_input, 'f', ptr)
    h_ini["ExposureTime"], ptr = decoder(bytes_input, 'f', ptr)
    # skip reserved word location
    ptr += 8

    h_ini["Width"], ptr = decoder(bytes_input, 'H', ptr)
    h_ini["Height"], ptr = decoder(bytes_input, 'H', ptr)
    h_ini["OffsetX"], ptr = decoder(bytes_input, 'H', ptr)
    h_ini["OffsetY"], ptr = decoder(bytes_input, 'H', ptr)
    h_ini["FlipLR"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["FlipUD"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["TestImageSelector"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["SensorWellDepth"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["AcquisitionFrameRate"], ptr = decoder(bytes_input, 'f', ptr)
    h_ini["TriggerDelay"], ptr = decoder(bytes_input, 'f', ptr)
    h_ini["TriggerMode"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["TriggerSource"], ptr = decoder(bytes_input, 'B', ptr)
    # skip reserved word location
    ptr += 1

    h_ini["FrameBufferMode"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["ExposureMode"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["HybridOutputEnabled"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["IntegrationMode"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["CalibrationReferenceScene"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["AveragingNumber"], ptr = decoder(bytes_input, 'H', ptr)
    h_ini["AveragingEnabled"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["SpectralFilterWheelMode"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["SpectralFilterWheelSpeedSetpoint"], ptr = decoder(bytes_input, 'f', ptr)
    h_ini["InternalLensTubeTemperatureSetpoint"], ptr = decoder(bytes_input, 'h', ptr)
    h_ini["PostProcessingInfo"], ptr = decoder(bytes_input, 'H', ptr)
    h_ini["AECPriorityMode"], ptr = decoder(bytes_input, 'B', ptr)
    # skip reserved word location
    ptr = ptr + 3

    h_ini["AECResponseTime"], ptr = decoder(bytes_input, 'f', ptr)
    h_ini["AECWellFillingTarget"], ptr = decoder(bytes_input, 'f', ptr)
    h_ini["AECHotSpotMaxSize"], ptr = decoder(bytes_input, 'f', ptr)
    # skip reserved word location
    ptr += 12

    h_ini["TimeSource"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["ICUPosition"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["SensorTemperatureRaw"], ptr = decoder(bytes_input, 'H', ptr)
    h_ini["POSIXTime"], ptr = decoder(bytes_input, 'I', ptr)
    h_ini["SubSecondTime"], ptr = decoder(bytes_input, 'I', ptr)
    h_ini["GPSLongitude"], ptr = decoder(bytes_input, 'i', ptr)
    h_ini["GPSLatitude"], ptr = decoder(bytes_input, 'i', ptr)
    h_ini["GPSAltitude"], ptr = decoder(bytes_input, 'i', ptr)
    h_ini["SpectralFilterWheelEncoderAtExposureStart"], ptr = decoder(bytes_input, 'H', ptr)
    h_ini["SpectralFilterWheelEncoderAtExposureEnd"], ptr = decoder(bytes_input, 'H', ptr)
    h_ini["AnalogInputValueChannel1"], ptr = decoder(bytes_input, 'H', ptr)
    h_ini["AnalogInputValueChannel2"], ptr = decoder(bytes_input, 'H', ptr)
    h_ini["AnalogInputValueChannel3"], ptr = decoder(bytes_input, 'H', ptr)
    h_ini["AnalogInputValueChannel4"], ptr = decoder(bytes_input, 'H', ptr)
    h_ini["GPSModeIndicator"], ptr = decoder(bytes_input, 'B', ptr)
    # skip reserved word location
    ptr += 15

    h_ini["ExternalBlackBodyTemperature"], ptr = decoder(bytes_input, 'f', ptr)
    # skip reserved word location
    ptr += 4

    h_ini["DeviceTemperatureSensor"], ptr = decoder(bytes_input, 'h', ptr)
    # skip reserved word location
    ptr += 2

    h_ini["DeviceTemperatureInternalLens"], ptr = decoder(bytes_input, 'h', ptr)
    h_ini["DeviceTemperatureExternalLens"], ptr = decoder(bytes_input, 'h', ptr)
    h_ini["DeviceTemperatureInternalCalibrationUnit"], ptr = decoder(bytes_input, 'h', ptr)
    h_ini["DeviceTemperatureLCCThermistor"], ptr = decoder(bytes_input, 'h', ptr)
    h_ini["DeviceTemperatureROICFPGA"], ptr = decoder(bytes_input, 'h', ptr)
    h_ini["DeviceTemperatureROICPCB"], ptr = decoder(bytes_input, 'h', ptr)
    h_ini["DeviceTemperatureCameraLinkFPGA"], ptr = decoder(bytes_input, 'h', ptr)
    h_ini["DeviceTemperatureCameraLinkPCB"], ptr = decoder(bytes_input, 'h', ptr)
    h_ini["DeviceTemperatureExternalThermistor"], ptr = decoder(bytes_input, 'h', ptr)
    h_ini["DeviceTemperatureSpectralFilterWheel"], ptr = decoder(bytes_input, 'h', ptr)
    h_ini["DeviceTemperatureCompressor"], ptr = decoder(bytes_input, 'h', ptr)
    h_ini["DeviceTemperatureColdFinger"], ptr = decoder(bytes_input, 'h', ptr)
    h_ini["BadPixelsRatio"], ptr = decoder(bytes_input, 'f', ptr)
    h_ini["SaturatedPixelsRatio"], ptr = decoder(bytes_input, 'f', ptr)
    # skip reserved word location
    ptr += 8

    h_ini["RawSaturationLevel"], ptr = decoder(bytes_input, 'H', ptr)
    # skip reserved word location
    ptr += 2

    h_ini["SensorWidth"], ptr = decoder(bytes_input, 'H', ptr)
    h_ini["SensorHeight"], ptr = decoder(bytes_input, 'H', ptr)
    h_ini["FactoryCalibrationDataSetPOSIXTime"], ptr = decoder(bytes_input, 'I', ptr)
    h_ini["ExternalLensID"], ptr = decoder(bytes_input, 'I', ptr)
    h_ini["DeviceModelName"], ptr = decoder(bytes_input, 'c20', ptr)
    h_ini["DeviceFirmwareVersion"], ptr = decoder(bytes_input, 'c8', ptr)
    h_ini["DeviceID"], ptr = decoder(bytes_input, 'c8', ptr)

    return h_ini
