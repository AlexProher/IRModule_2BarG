import numpy as np
import struct


def decoder(bytes_passed, c_type, decoding_index):
    """
    :param bytes_passed: bytes à décoder
    :param c_type: str de 1 charactère de long indiquant le type de données des bytes à décoder
    :param decoding_index: index de positionnement dans la lecture du header

    :return: les valeurs décodées
    """
    byte_len = 1
    data_type = 0
    string_flag = 0
    if c_type == 'B':
        byte_len = 1
        data_type = np.uint8
    elif c_type == 'b':
        byte_len = 1
        data_type = np.int8
    elif c_type == 'H':
        byte_len = 2
        data_type = np.uint16
    elif c_type == 'h':
        byte_len = 2
        data_type = np.int16
    elif c_type == 'I':
        byte_len = 4
        data_type = np.uint32
    elif c_type == 'i':
        byte_len = 4
        data_type = np.int32
    elif c_type == 'f':
        byte_len = 4
        data_type = np.float32
    elif c_type[0] == 'c':
        string_flag = 1
        byte_len = int(c_type[1:])
        c_type = ''
        for i in range(0, byte_len):
            c_type += 'c'
        data_type = np.dtype(str)

    bytes_reshaped = np.reshape(bytes_passed[:, decoding_index: decoding_index + byte_len], [1, -1])[0]
    decoded_value_stored = []
    file_idx = 0
    for frame_idx in range(0, len(bytes_reshaped)):
        if file_idx >= len(bytes_reshaped):
            break
        if string_flag:
            # mettre du code pour gérer le cas de string
            decoded_value = struct.unpack(c_type, bytes_reshaped[file_idx: file_idx + byte_len])
            decoded_value_str = ''
            for i in range(0, len(decoded_value)):
                decoded_value_str += decoded_value[i].decode('utf8')
            decoded_value_stored.append(decoded_value_str)
            file_idx += byte_len
        else:
            decoded_value = struct.unpack(c_type, bytes_reshaped[file_idx: file_idx + byte_len])[0]
            decoded_value_stored.append(decoded_value)
            file_idx += byte_len
    decoded_value_stored = np.asarray(decoded_value_stored, dtype=data_type)
    decoding_index += byte_len
    return decoded_value_stored, decoding_index
