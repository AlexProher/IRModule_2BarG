import numpy as np
from TelopsToolbox.hcc.SequenceReaderP import SequenceReaderP
from tkinter.filedialog import askopenfilenames


def read_ircam(file_name, peek=False, headers_only=False, frames=float('Inf'), rows=float('Inf'), pixels=float('Inf'),
               spassignment='max', bpassignment='median'):
    """
    readIRCam Image sequence reader for Telops infrared camera files (.hcc)

    data, _, _, _ = read_ircam(filename, **kwargs) reads a single file, or a sequence of files, as output from Telops
    infrared cameras. Data is an array of frames containing pixel values along colums (<NFrames x NPixels>).

    data, header, _, _ = readIRCam(...) also reads image headers, each frame having its own header.

    To obtain a rectangular matrix of a frame for imaging purposes, one should reshape "Data" like this:
        data_im = np.reshape(data[i, :], (header["Width"][i], Header["Height"][i]);


    _, _, SaturatedPixels, BadPixels] = readIRCam(...) enables to extract supplementary parameters about frame validity,
    and identification of saturated or bad pixels.

    ... = readIRCam(file_name, param1=value1, param2=value2, ...) allows to change certain default parameters

    Parameter name      Value
    --------------      -----
    'Peek'              A logical value. If true, "Data" is replaced by the number of frames contained within the
                        sequence "filename". When the sequence inculdes multiple files, "Data" returns a vector of the
                        number of frames of each file. "Header" (if required) contains the header of the first frame of
                        the sequence.
                        The default value is false.

    'HeadersOnly'       A logical value. If true, only the frame headers are read.
                        The default value is false.

    'Frames'            A Single non-negative integer value, or list of values, stating the specific frames that have to
                        read. USAGE : frames=np.asarray([ list of indices of desired frames ])
                        The default values is all frames.

    'Rows'              A single non-negative integer value, or list of values, stating the specific rows that have to
                        read. USAGE : rows=np.asarray([ list of indices of desired rows ])
                        The default value is all rows.

    'SPAssignment'      The method used to assign a value to each saturated pixel. The possible methods are: 'max',
                        'median' and 'nan'.
                        Only available for XML >= 10.
                        The default method is 'max'.


    'BPAssignment'      The method used to assign a value to each bad pixel. The possible methods are: 'median' and
                        'nan'.
                        Only available for XML >= 10.
                        The default method is 'median'

    INPUT
        file_name : a string pointing to a single file or to a set of files with a common name (e.g.
                   'path_to_file/filename.hcc' or 'path_to_file/commonname*.hcc'), it may also be a liste (or tuple) of
                   strings (e.g. ['filename1.hcc', 'filename2*.hcc'])

    OUTPUT
        Data : pixel data
                - <NFrames, Width x Height> array by default
                - <NFrames, NRows x Height> array when specific 'Rows' are requested
                - empty array when only 'HeadersOnly' is requested
        Header : a dictionnary of arrays of size <Nframes x 1>. To access the element "ELEMENT" of the frame "i", you
                would type Header["ELEMENT"][i]
        specialPixelMap : Map of the special pixels with the corresponding code
        specialNonBadPixelMap : Map of the special pixel after bad pixel replacement
        The special pixel code are :
           LowerDigitalSaturation = 1;
           UpperDigitalSaturation = 2;
           SpecialTag3 = 3;
           SpecialTag4 = 4;
           SpecialTag5 = 5;
           SpecialTag6 = 6;
           SpecialTag7 = 7;
           SpecialTag8 = 8;
           SpecialTag9 = 9;
           BlankImageTranslation = 10;
           BadEmissivityCorrection = 11;
           UnderCalibrationRange = 12;
           OverCalibrationRange = 13;
           BadPixelTag = 14;          % Code for bad pixel
           SaturatedPixelTag = 15;    % Code for saturated pixel

    USAGE
        ... = read_ircam(filename)   # all frames, all rows

        ... = read_ircam(filename, headers_only=True)   # read headers only

        ... = read_ircam(filename, headers_only=True, frames=list(range(XX, YY))  # headers only, frames xx to yy

        ... = read_ircam(filename, frames=ii, rows=list(range(XX, YY))   # only frame ii, rows xx through yy

        ... = read_ircam(filename, rows=xx)   # all frames, row xx only

        n, _, _, _ = readIRCam(filename, peek=True)   # number of frames in the sequence

        ... = readIRCam(filename, spassignment='nan')   # all saturated pixels are assigned to 'nan'

        ... = readIRCam(filename, bpassignment='nan')   # all bad pixels are assigned to 'nan'

    Private parameters are:

        Parameter name      Value
        --------------      -----
        'rows'              When the list of rows does not correspond to a set of complete and consecutive rows the
                            'median' assignment methods are not possible, so they are forced to 'nan'.

        'pixels'            A single non-negative integer value, or list of values, stating the specific pixels that
                            have to be read.
                            When the list of pixels does not correspond to a set of complete and consecutive rows the
                            'median' assignment methods are not possible, so they are forced to 'nan'.
                            The default value is all pixels.
                            Usage : ... = read_ircam(..., pixels=np.asarray([ list of pixels to read ]))

        'spassignment'      The method used to replace the saturated pixels. The possible private method is: 'no'.

        'bpassignment'      The method used to replace the bad pixels. The possible private method is 'no'.

    Compagnie : Telops Inc.
    -----  Registre de changements :  ----------------------------------------------------------------------------------
    Version     Date            Nom     Commentaires
    0.0         25 Jul 2019     BTU     Initial port of the matlab code
    0.1         12 Mai 2020     JTH     Code cleanup and bug fixes

    Copyright Telops 2019

    """

    # Initialisation
    # création de l'objet "SequenceReaderP"
    fichier_sr = SequenceReaderP(file_name)
    # définition de la méthode d'assignation des pixels saturés
    fichier_sr.spassignment_method = spassignment
    # définition de la méthode d'assignation des pixels défectueux
    fichier_sr.bpassignment_method = bpassignment

    # sélection de toutes les images
    if np.array_equal(frames, float('Inf')):
        frames = np.linspace(0, fichier_sr.length-1, fichier_sr.length, dtype=int)
    else:
        frames = np.asarray(frames)

    # Sélection des pixels
    # - sélection de pixels a préséance sur la sélection de rangées
    if pixels == float('Inf'):
        if np.array_equal(rows, float('Inf')):
            # sélection de toutes les rangées
            pixels = np.linspace(0, int(fichier_sr.width) * int(fichier_sr.height) - 1,
                                 int(fichier_sr.width) * int(fichier_sr.height), dtype=int)
        else:
            rows = np.asarray(rows)
            pixels = np.zeros((1, (rows.size * fichier_sr.width)))
            if rows.size > 1:
                counter = 0
                for row in rows:
                    pixels[0, counter: counter + fichier_sr.width] = np.linspace(row * fichier_sr.width,
                                                                                 (row + 1) * fichier_sr.width,
                                                                                 fichier_sr.width, dtype=int)
                    counter += fichier_sr.width
                pixels = pixels[0]
            else:
                pixels = np.linspace(rows * fichier_sr.width, (rows + 1) * fichier_sr.width, fichier_sr.width, dtype=int)

    # Mode "Peek"
    if peek:
        data = fichier_sr.private_length
        header = fichier_sr.header
        return data, header, None, None

    # mode "HeadersOnly"
    if headers_only:
        # lecture des en-têtes seulement
        header = fichier_sr.frame(frames)[0]
        return None, header, None, None

    # lecture des images sélectionnées
    data, header, special_pixel_map, special_nonbad_pixel_map = fichier_sr.fetch(frames, pixels)
    return data, header, special_pixel_map, special_nonbad_pixel_map


# ----------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':
    fileNames = askopenfilenames(title="Select the .hcc", filetypes=[("hcc files", ".hcc")])
    Data, Header, specialPixelMap, specialNonBadPixelMap = read_ircam(fileNames)
