import numpy as np


def read_ircam_header_b(bytes_input):
    """
    Decode header portion of a Telops image (.hcc format), with appropriate adjustments

      H = readIRCamHeader(bytes);

      INPUT
          bytes: an array of headers in uint8 (byte) format <Nframes x Nbytes>

      OUTPUT
          H: an array of header structures <Nframes x 1>

    Auteur : Pierre Tremblay ing.
    Compagnie : Telops Inc.
    -----  Registre de changements :  ------------------------------------------------------
    Version  Date          Nom    Commentaires
    1.0      18 Oct 2017   PTR    Création
    1.1      25 Avr 2018   PTR    Gestion version XML (majeure et mineure) ; généralisation
                                  de la conversion de champs en valeurs réelles

     Copyright Telops 2009,2018
    """

    # VALIDATION DE LA VERSION XML MINEURE
    # identification de la version XML majeure
    device_xml_major_version = bytes_input[0, 3]
    # identification de la version XML mineure
    device_xml_minor_version = bytes_input[0, 2]

    # décodage des champs de l'en-tête (ou des en-têtes)
    try:
        exec("from TelopsToolbox.hcc.decoders.readIRCamHeaderV{}m{} "
             "import read_ircam_header_v{}m{} as read_header".format(device_xml_major_version, device_xml_minor_version,
                                                                     device_xml_major_version, device_xml_minor_version)
             , globals())
    except ModuleNotFoundError:
        raise ValueError("Unknown file header version {}.{}. Contact Telops".format(device_xml_major_version,
                                                                                    device_xml_minor_version))

    h = read_header(bytes_input)
    if isinstance(bytes_input, bytes):
        if h["ExposureTime"].dtype == np.uint32:
            h["ExposureTime"] = np.asarray(h["ExposureTime"] / 100, dtype=np.float32)

        # - conversion en hertz
        if h["AcquisitionFrameRate"].dtype == np.uint32:
            h["AcquisitionFrameRate"] = np.asarray(h["AcquisitionFrameRate"] / 1000, dtype=np.float32)

        # - conversion en degrés
        if 'HFOV' in h:
            h["HFOV"] = np.asarray(h["HFOV"] / 10, dtype=np.float32)

        # - conversion en degrés
        if 'VFOV' in h:
            h["VFOV"] = np.asarray(h["VFOV"] / 10, dtype=np.float32)

        # - conversion en unités standard de température
        liste_temperatures = []
        champs_h = list(h.keys())
        for key in champs_h:
            if key.startswith("Temperature"):
                liste_temperatures.append(key)

        for i in range(0, len(liste_temperatures)):
            kelvin = "TemperatureSensor" in liste_temperatures[i]
            if kelvin:
                # conversion en kelvins
                h[liste_temperatures[i]] = np.asarray(h[liste_temperatures[i]] / 100 + 273.15, dtype=np.float32)
            else:
                # conversion en degrés Celsius
                h[liste_temperatures[i]] = np.asarray(h[liste_temperatures[i]] / 100, dtype=np.float32)
    else:
        if h["ExposureTime"][0].dtype == np.uint32:
            h["ExposureTime"] = np.asarray(h["ExposureTime"] / 100, dtype=np.float32)

        # - conversion en hertz
        if h["AcquisitionFrameRate"][0].dtype == np.uint32:
            h["AcquisitionFrameRate"] = np.asarray(h["AcquisitionFrameRate"] / 1000, dtype=np.float32)

        # - conversion en degrés
        if 'HFOV' in h:
            h["HFOV"] = np.asarray(h["HFOV"] / 10, dtype=np.float32)

        # - conversion en degrés
        if 'VFOV' in h:
            h["VFOV"] = np.asarray(h["VFOV"] / 10, dtype=np.float32)

        # - conversion en unités standard de température
        liste_temperatures = []
        champs_h = list(h.keys())
        for key in champs_h:
            if key.startswith("Temperature"):
                liste_temperatures.append(key)

        for i in range(0, len(liste_temperatures)):
            kelvin = "TemperatureSensor" in liste_temperatures[i]
            if kelvin:
                # conversion en kelvins
                h[liste_temperatures[i]] = np.asarray(h[liste_temperatures[i]] / 100 + 273.15, dtype=np.float32)
            else:
                # conversion en degrés Celsius
                h[liste_temperatures[i]] = np.asarray(h[liste_temperatures[i]] / 100, dtype=np.float32)

    return h
