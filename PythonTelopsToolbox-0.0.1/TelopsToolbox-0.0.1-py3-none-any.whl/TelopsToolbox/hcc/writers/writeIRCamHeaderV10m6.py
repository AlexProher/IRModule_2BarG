import struct
import warnings


def write_ircam_header_v10m6(fid, header):
    """
    Write the header structure of an IRCam image into file pointed by fid.
        write_ircam_header_v10m6(fid, header)

        INPUT
            A file descriptor with current position pointing to the beginning of the header.

        "auto-generated function for header writing.
         based on Excel header file definition version 10m6"

         DO NOT MANUALLY MODIFY THIS CODE!
    """

    init_offset = fid.tell()
    fid.write(struct.pack('<cc', bytes(header["Signature"][0], 'utf-8'), bytes(header["Signature"][1], 'utf-8')))
    fid.write(struct.pack('<B', header["DeviceXMLMinorVersion"]))
    fid.write(struct.pack('<B', header["DeviceXMLMajorVersion"]))
    fid.write(struct.pack('<H', header["ImageHeaderLength"]))
    # skip reserved word location
    fid.write(struct.pack('<BB', 0, 0))

    fid.write(struct.pack('<I', header["FrameID"]))
    fid.write(struct.pack('<f', header["DataOffset"]))
    fid.write(struct.pack('<b', header["DataExp"]))
    # skip reserved word location
    fid.write(struct.pack('<BBBBBBB', 0, 0, 0, 0, 0, 0, 0))
    fid.write(struct.pack('<I', header["ExposureTime"]))
    fid.write(struct.pack('<B', header["CalibrationMode"]))
    fid.write(struct.pack('<B', header["BPRApplied"]))
    fid.write(struct.pack('<B', header["FrameBufferMode"]))
    fid.write(struct.pack('<B', header["CalibrationBlockIndex"]))
    fid.write(struct.pack('<H', header["Width"]))
    fid.write(struct.pack('<H', header["Height"]))
    fid.write(struct.pack('<H', header["OffsetX"]))
    fid.write(struct.pack('<H', header["OffsetY"]))
    fid.write(struct.pack('<B', header["ReverseX"]))
    fid.write(struct.pack('<B', header["ReverseY"]))
    fid.write(struct.pack('<B', header["TestImageSelector"]))
    fid.write(struct.pack('<B', header["SensorWellDepth"]))
    fid.write(struct.pack('<I', header["AcquisitionFrameRate"]))
    fid.write(struct.pack('<f', header["TriggerDelay"]))
    fid.write(struct.pack('<B', header["TriggerMode"]))
    fid.write(struct.pack('<B', header["TriggerSource"]))
    fid.write(struct.pack('<B', header["IntegrationMode"]))
    # skip reserved word location
    fid.write(struct.pack('<B', 0))

    fid.write(struct.pack('<B', header["AveragingNumber"]))
    # skip reserved word location
    fid.write(struct.pack('<BB', 0, 0))

    fid.write(struct.pack('<B', header["ExposureAuto"]))
    fid.write(struct.pack('<f', header["AECResponseTime"]))
    fid.write(struct.pack('<f', header["AECImageFraction"]))
    fid.write(struct.pack('<f', header["AECTargetWellFilling"]))
    # skip reserved word location
    fid.write(struct.pack('<BBBBBBBBBBBBBBBBBBBBBBBBBBBB', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                          0, 0, 0, 0, 0, 0, 0, 0))

    fid.write(struct.pack('<I', header["POSIXTime"]))
    fid.write(struct.pack('<I', header["SubSecondTime"]))
    fid.write(struct.pack('<B', header["TimeSource"]))
    # skip reserved word location
    fid.write(struct.pack('<BB', 0, 0))

    fid.write(struct.pack('<B', header["GPSModeIndicator"]))
    fid.write(struct.pack('<i', header["GPSLongitude"]))
    fid.write(struct.pack('<i', header["GPSLatitude"]))
    fid.write(struct.pack('<i', header["GPSAltitude"]))
    # skip reserved word location
    fid.write(struct.pack('<BBBB', 0, 0, 0, 0))

    fid.write(struct.pack('<B', header["FWPosition"]))
    fid.write(struct.pack('<B', header["ICUPosition"]))
    fid.write(struct.pack('<B', header["NDFilterPosition"]))
    fid.write(struct.pack('<B', header["EHDRIExposureIndex"]))
    fid.write(struct.pack('<B', header["FrameFlag"]))
    fid.write(struct.pack('<B', header["PostProcessed"]))
    fid.write(struct.pack('<H', header["SensorTemperatureRaw"]))
    fid.write(struct.pack('<I', header["AlarmVector"]))
    # skip reserved word location
    fid.write(struct.pack('<BBBBBBBBBBBBBBBB', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0))

    fid.write(struct.pack('<f', header["ExternalBlackBodyTemperature"]))
    fid.write(struct.pack('<h', header["TemperatureSensor"]))
    # skip reserved word location
    fid.write(struct.pack('<BB', 0, 0))

    fid.write(struct.pack('<h', header["TemperatureInternalLens"]))
    fid.write(struct.pack('<h', header["TemperatureExternalLens"]))
    fid.write(struct.pack('<h', header["TemperatureInternalCalibrationUnit"]))
    # skip reserved word location
    fid.write(struct.pack('<BBBBBBBBBB', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0))

    fid.write(struct.pack('<h', header["TemperatureExternalThermistor"]))
    fid.write(struct.pack('<h', header["TemperatureFilterWheel"]))
    fid.write(struct.pack('<h', header["TemperatureCompressor"]))
    fid.write(struct.pack('<h', header["TemperatureColdFinger"]))
    # skip reserved word location
    fid.write(struct.pack('<BBBBBBBBBBBBBBBBBBBBBBBB', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                          0, 0))

    fid.write(struct.pack('<I', header["CalibrationBlockPOSIXTime"]))
    fid.write(struct.pack('<I', header["ExternalLensSerialNumber"]))
    fid.write(struct.pack('<I', header["ManualFilterSerialNumber"]))
    fid.write(struct.pack('<B', header["SensorID"]))
    fid.write(struct.pack('<B', header["PixelDataResolution"]))
    # skip reserved word location
    fid.write(struct.pack('<BBBBBBBBB', 0, 0, 0, 0, 0, 0, 0, 0, 0))

    fid.write(struct.pack('<B', header["DeviceCalibrationFilesMajorVersion"]))
    fid.write(struct.pack('<B', header["DeviceCalibrationFilesMinorVersion"]))
    fid.write(struct.pack('<B', header["DeviceCalibrationFilesSubMinorVersion"]))
    fid.write(struct.pack('<B', header["DeviceDataFlowMajorVersion"]))
    fid.write(struct.pack('<B', header["DeviceDataFlowMinorVersion"]))
    fid.write(struct.pack('<B', header["DeviceFirmwareMajorVersion"]))
    fid.write(struct.pack('<B', header["DeviceFirmwareMinorVersion"]))
    fid.write(struct.pack('<B', header["DeviceFirmwareSubMinorVersion"]))
    fid.write(struct.pack('<B', header["DeviceFirmwareBuildVersion"]))
    fid.write(struct.pack('<I', header["ActualizationPOSIXTime"]))
    fid.write(struct.pack('<I', header["DeviceSerialNumber"]))
    # skip reserved word location
    fid.write(struct.pack('<BBBB', 0, 0, 0, 0))

    # Check if versions are compatible
    if header["DeviceXMLMajorVersion"] != 10:
        raise FileNotFoundError('This function supports XML Version 10m6, but the header H asks for Version {}.{}'
                                .format(header["DeviceXMLMajorVersion"], header["DeviceXMLMinorVersion"]))
    if header["DeviceXMLMinorVersion"] != 6:
        warnings.warn('TelopsXmlMinorVersionMismatch : '
                      'This function supports XML version 10m6, but the header asks for version {}.{}'
                      .format(header["DeviceXMLMjaorVersion"], header["DeviceXMLMinorVersion"]))

    curr_pos = fid.tell() - init_offset
    # skip to the beginning of the data
    offset = header["ImageHeaderLength"] - curr_pos
    for i in range(0, offset):
        fid.write(struct.pack('<B', 0))
