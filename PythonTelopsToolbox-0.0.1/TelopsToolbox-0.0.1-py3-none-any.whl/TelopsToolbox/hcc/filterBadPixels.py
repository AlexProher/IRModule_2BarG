import numpy as np
from TelopsToolbox.utils.image_processing import get_aoi_indices
from decimal import Decimal, ROUND_HALF_UP


def filter_bad_pixels(bpmap, width, height, scene, aoi=0, recurse=False):
    """  ***************************************************************************************************************
    Replace the bad pixels of a scene with the median of their nearest neighbours.
    corr_im, uncorr_bp = filterBadPixels(badpixels, width, height, Scene, AOI, param1, value1, ...)

    Filter the bad pixels bpmap using a spatial median filter (8-neighbour connectivity) on the input scene. The scene
    has (width x height) pixels, unless the subwindow AOI is defined, in which case, the width and height represent the
    greater frame into which the AOI is defines.

    INPUTS
        bpmap   :   [-] This is a vector (N x 1) containing the index position of the bad pixels on the detector, or a
                    Nx1 logical vector
        width   :   [pixels] Horizontal size of the window or the FPA (depending on the AOI input).
        height  :   [pixels] Vertical size of the window or the FPA (depending on the AOI input).
        Scene   :   [a.u.] Scene to be corrected. This scene can be a calibrated or non calibrated datacube or image.
                    The spatial information of the data corresponds to the row index of the matrix. The values in each
                    row represent the spectral or temporal information.
        AOI     :   [optional] Are of interest structure with fields .Width, .Height, .OffsetX, and .OffsetY,
                    corresponding to the subwindow containing the scene.

    Properties:
        'recurse'   :   {true, false}, loop until all bad pixels are corrected. Default is false.

    OUTPUTS
        corr_im     :   Same information as in the 'Scene' input, but the bad pixels are replaced by the median of their
                        valid neighbours (maximum of 8 neighbours).
        uncorr_bp   :   The list of pixels that have not been corrected.
        repMap      :   The map of replacement indices. It has the same dimensions as the
                        'Scene' <Nim x Npx>, since each frame ends with its own replacement map.

    Examples:

    Ex. 1: the scene is a subwindow H AOI of a 320x256 detector.
    scene, DH, H = readHyperCam(filename);
    sceneCorr, _, _ = filterBadPixels(bpmap, H["SensorWidth"], H["SensorHeight"], scene, aoi=H);

    Ex. 2: the bad pixel map is in the data vector referential
    scene, DH, H = readHyperCam(filename);
    sceneCorr, _, _ = filterBadPixels(bpmap, H["XSize"], H["YSize"], scene);

    Copyright Telops 2019
    """

    pep8_savior1 = aoi
    pep8_savior2 = 0
    if pep8_savior1 == 0:
        pep8_savior2 += 1

    aoi = {
        "Width": float(width),
        "Height": float(height),
        "OffsetX": 0,
        "OffsetY": 0
    }

    if type(recurse) == str:
        recurse = (recurse == 'on')

    rep_indices = np.tile(np.linspace(0, int(width) * int(height) - 1, int(width) * int(height), dtype=int),
                          [scene.shape[0], 1])

    # base condition for the recursive function
    if len(bpmap) == 0:
        return scene, [], rep_indices

    bpmap_verifier = np.ones(bpmap.shape) * 0.5
    hood_islogical = np.isclose(bpmap, bpmap_verifier, rtol=0.51)
    if np.all(hood_islogical):
        bpmap = np.where(bpmap > 0)

    bpmap_verifier = None
    hood_islogical = None
    del bpmap_verifier
    del hood_islogical

    # all pixels are bad
    if np.array_equal(rep_indices, bpmap.sort()):
        return scene, bpmap, rep_indices

    # Cast to single because IRCam header values are uint16 and it creates problems when used in calculations
    aoi["Width"] = float(aoi["Width"])
    aoi["Height"] = float(aoi["Height"])
    aoi["OffsetX"] = float(aoi["OffsetX"])
    aoi["OffsetY"] = float(aoi["OffsetY"])

    # FlipLR and FlipUD must be 0, since we work in the FPA referential (not used for imaging)
    f = {
        "Width": width,
        "Height": height,
        "FlipLR": 0,
        "FlipUD": 0
    }

    # get all indices from the subwindow and intersect them with idx_in
    aoi_idx, _ = get_aoi_indices(f, aoi)

    uncorr_bp_left = 1
    corr_scene = scene
    uncorr_bp_maj = np.asarray([])

    while uncorr_bp_left == 1:
        uncorr_bp_maj = np.asarray([])
        sub_bpmap = np.intersect1d(bpmap, aoi_idx)
        sub_bpmap = np.asarray(sub_bpmap, dtype=int)
        # extract the indices corresponding to the subwindow and translate them by (-AOI.OffsetX, -AOI.OffsetY)

        # we need to find vertical indices in the absolute referential
        yy_and_xx = np.unravel_index(sub_bpmap, (f["Height"], f["Width"]), order='F')   # F pour column-major
        yy = yy_and_xx[0]
        xx = yy_and_xx[1]
        yy_and_xx_offset = (np.asarray(yy - aoi["OffsetY"], dtype=int), np.asarray(xx - aoi["OffsetX"], dtype=int))

        # the translated indices j are giver by j = w0 * (y - y0) + x - x0
        # where w0 is the width of the subwindow
        sub_bpmap = np.ravel_multi_index(yy_and_xx_offset, (int(aoi["Height"]), int(aoi["Width"])), order='F')

        """
        #####################################################################
        ### Identify bad pixels that are on the edge or corner of the map ###
        #####################################################################
        """
        size_x = aoi["Width"]
        size_y = aoi["Height"]

        k = np.reshape(sub_bpmap, (-1, 1))
        k1 = k[np.logical_and(k < (size_x - 1), k > 0)]   # left edge bad pixels
        k2 = k[np.logical_and(k > size_y * size_x - size_x, k < (size_x * size_y) - 1)]   # right edge bad pixels
        k3 = k[np.logical_and(np.logical_and(np.mod(k + 1, size_x) == 0, k > (size_x - 1)),
                              k < ((size_x * size_y) - 1))]   # bottom edge bad pixels
        k4 = k[np.logical_and(np.logical_and(np.mod(k, size_x) == 0, k > 0),
                              k < (size_y * size_x - size_x))]   # top edge bad pixels
        k5 = k[k == 0]   # top left corner bad pixel
        k6 = k[k == size_x - 1]   # bottom left corner bad pixel
        k7 = k[k == size_y * size_x - size_x]   # Top right corner bad pixel
        k8 = k[k == size_y * size_x - 1]   # Bottom right corner bad pixel
        k9 = np.setdiff1d(k, np.concatenate((k1, k2, k3, k4, k5, k6, k7, k8)))
        """
        ##########################################################
        ### Find Median of neighbours to correct image or cube ###
        ##########################################################
        """
        if len(k9) != 0:   # correct bad pixels not touching the edge if any
            indices = np.array([   # vecteur contenant les indices de tous les pixels voisins de bad pixels
                k9 - size_x - 1, k9 - 1, k9 + size_x - 1,
                k9 - size_x,             k9 + size_x,
                k9 - size_x + 1, k9 + 1, k9 + size_x + 1
            ], dtype=int).transpose()
            medvals, uncorr_bp, rep_indices[:, k9] = median_no_bp(scene, indices, k)
            corr_scene[:, k9] = medvals
            uncorr_bp_maj = np.append(uncorr_bp_maj, k9[uncorr_bp])

        if len(k1) != 0:   # correct left edge bad pixels, if any
            indices = np.array([
                k1 - 1, k1 + size_x - 1,
                k1 + size_x,
                k1 + 1, k1 + size_x + 1
            ], dtype=int).transpose()
            medvals, uncorr_bp, rep_indices[:, k1] = median_no_bp(scene, indices, k)
            corr_scene[:, k1] = medvals
            uncorr_bp_maj = np.append(uncorr_bp_maj, k1[uncorr_bp])

        if len(k2) != 0:   # correct right edge bad pixels, if any
            indices = np.array([
                k2 - size_x - 1, k2 - 1,
                k2 - size_x,
                k2 - size_x + 1, k2 + 1
            ], dtype=int).transpose()
            medvals, uncorr_bp, rep_indices[:, k2] = median_no_bp(scene, indices, k)
            corr_scene[:, k2] = medvals
            uncorr_bp_maj = np.append(uncorr_bp_maj, k2[uncorr_bp])

        if len(k3) != 0:   # correct bottom edge bad pixels if any
            indices = np.array([
                k3 - size_x - 1, k3 - 1, k3 + size_x - 1,
                k3 - size_x,             k3 + size_x
            ], dtype=int).transpose()
            medvals, uncorr_bp, rep_indices[:, k3] = median_no_bp(scene, indices, k)
            corr_scene[:, k3] = medvals
            uncorr_bp_maj = np.append(uncorr_bp_maj, k3[uncorr_bp])

        if len(k4) != 0:   # correct top edge bad pixels if any
            indices = np.array([
                k4 - size_x,            k4 + size_x,
                k4 - size_x + 1, k4 + 1, k4 + size_x + 1
            ], dtype=int).transpose()
            medvals, uncorr_bp, rep_indices[:, k4] = median_no_bp(scene, indices, k)
            corr_scene[:, k4] = medvals
            uncorr_bp_maj = np.append(uncorr_bp_maj, k4[uncorr_bp])

        if len(k5) != 0:
            indices = np.array([
                k5 + size_x,
                k5 + 1, k5 + size_x + 1
            ], dtype=int).transpose()
            medvals, uncorr_bp, rep_indices[:, k5] = median_no_bp(scene, indices, k)
            corr_scene[:, k5] = medvals
            uncorr_bp_maj = np.append(uncorr_bp_maj, k5[uncorr_bp])

        if len(k6) != 0:
            indices = np.array([
                k6 - 1, k6 + size_x - 1,
                k6 + size_x
            ], dtype=int).transpose()
            medvals, uncorr_bp, rep_indices[:, k6] = median_no_bp(scene, indices, k)
            corr_scene[:, k6] = medvals
            uncorr_bp_maj = np.append(uncorr_bp_maj, k6[uncorr_bp])

        if len(k7) != 0:
            indices = np.array([
                k7 - size_x,
                k7 - size_x + 1, k7 + 1
            ], dtype=int).transpose()
            medvals, uncorr_bp, rep_indices[:, k7] = median_no_bp(scene, indices, k)
            corr_scene[:, k7] = medvals
            uncorr_bp_maj = np.append(uncorr_bp_maj, k7[uncorr_bp])

        if len(k8) != 0:
            indices = np.array([
                k8 - size_x - 1, k8 - 1,
                k8 - size_x
            ], dtype=int).transpose()
            medvals, uncorr_bp, rep_indices[:, k8] = median_no_bp(scene, indices, k)
            corr_scene[:, k8] = medvals
            uncorr_bp_maj = np.append(uncorr_bp_maj, k8[uncorr_bp])

        uncorr_bp_maj = uncorr_bp_maj.astype('int')
        # we need to translate the bp back to the global frame referential
        yy_and_xx = np.unravel_index(uncorr_bp_maj, (int(aoi["Height"]), int(aoi["Width"])), order='F')
        yy = yy_and_xx[0]
        xx = yy_and_xx[1]

        # the translated indices j are given by j = w0 * (y - y0) + x - x0
        # where w0 is the width of the subwindow
        yy_and_xx_offset = (np.asarray(yy + aoi["OffsetY"], dtype=int), np.asarray(xx + aoi["OffsetX"], dtype=int))
        uncorr_bp_maj = np.ravel_multi_index(yy_and_xx_offset, (int(aoi["Height"]), int(aoi["Width"])), order='F')

        if np.array_equal(uncorr_bp_maj, bpmap):
            return corr_scene, uncorr_bp_maj, rep_indices
        if len(uncorr_bp_maj) == 0 or not recurse:   # exit
            uncorr_bp_left = 0
        else:   # continue with corrected scene as input
            scene = corr_scene
            bpmap = uncorr_bp_maj

    return corr_scene, uncorr_bp_maj, rep_indices


def median_no_bp(scene, indices, k):
    # Manually computes median values while removing BP neighbours from distribution.
    # Returns indices of uncorrected BP, due to large clusters with all BP neighbours.

    n_bp = indices.shape[0]   # number of BP analyzed
    n_neighbours = indices.shape[1]   # number of analyzed neighbour pixels

    values = np.reshape(scene[:, indices], (scene.shape[0], n_bp, n_neighbours))

    # for each BP, finds index of first non BP neighbour
    bp_neighbours = np.in1d(indices, np.transpose(k))
    bp_neighbours = np.reshape(bp_neighbours, indices.shape)
    kf = np.sum(bp_neighbours, 1) + 1   # relies on input map (instead of values kf = sum(vv < 0, 2)' + 1;) (?)
    uncorr_bp = np.where(kf > n_neighbours)

    medvals = values[:, :, 0]   # just a preallocation
    rep_indices = np.zeros(values[:, :, 0].shape)
    for i in range(0, indices.shape[0]):
        not_bp_neighbours = 1 - bp_neighbours[i, :]
        if np.any(not_bp_neighbours):   # at least one neighbour is healthy
            possible_vals = values[:, i, :]   # nb_frames x nb_neighbours
            possible_indices = indices[i, :]
            vals = np.empty((possible_vals.shape[0], np.sum(not_bp_neighbours)), dtype=int)
            vals_idx = 0
            r_idx = []
            for j in range(0, len(not_bp_neighbours)):
                if not_bp_neighbours[j] == 1:
                    vals[:, vals_idx] = possible_vals[:, j]
                    r_idx.append(possible_indices[j])
                    vals_idx += 1
            r_idx = np.asarray(r_idx, dtype=int)
            # input("Press Enter to continue ...")
            if vals.shape[1] > 1:   # if vals.shape[1] == 1, it means that there is only one healthy neighbour
                idx = np.argsort(vals, axis=-1, kind='quicksort')
                vals = np.sort(vals, axis=-1)
                r_idx = r_idx[idx]
                if idx.shape[0] == 1:
                    r_idx = np.reshape(r_idx, (1, 1, -1))
                else:
                    r_idx = np.reshape(r_idx, (r_idx.shape[0], 1, -1))
                if str(vals.shape[1] / 2)[-2:] == ".5":
                    selection = int(Decimal(vals.shape[1] / 2).quantize(Decimal(0), rounding=ROUND_HALF_UP)) - 1
                else:
                    selection = int(np.round(vals.shape[1] / 2)) - 1
                vals = vals[:, selection]
                r_idx = r_idx[:, :, selection]

            rep_indices[:, i] = np.transpose(r_idx)
            medvals[:, i] = np.transpose(vals)

    return medvals, uncorr_bp, rep_indices
