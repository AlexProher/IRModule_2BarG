import numpy as np


def write_ircam_header_b(fid, header):
    """
    Write the header structure of Telops image (.hcc format) into file pointed by fid.

        write_ircam_header_b(fid, header)

        INPUTS
            fid    :    a file descriptor with current position pointing to the beginning of the header
            header :    a header structure. MUST be a list of dictionnaries, and not a dictionnary of lists, as
                        readIRCam would return. Use function convertHeader to convert from dictionnary of lists to
                        list of dictionnaries

    Auteur : Pierre Tremblay ing.
    Compagnie : Telops Inc.

    Copyright Telops 2009, 2018
    """

    # Validation de la version XML (majeur et mineur)
    # identification de la version XML majeure
    device_xml_major_version = header["DeviceXMLMajorVersion"]
    # identification de la version XML mineure
    device_xml_minor_version = header["DeviceXMLMinorVersion"]

    # décodage des champs de l'en-tête (ou des en-têtes)
    try:
        exec("from TelopsToolbox.hcc.writers.writeIRCamHeaderV{}m{} "
             "import write_ircam_header_v{}m{} as write_header".format(device_xml_major_version,
                                                                       device_xml_minor_version,
                                                                       device_xml_major_version,
                                                                       device_xml_minor_version), globals())
    except ModuleNotFoundError:
        raise ValueError("Unknown file header version {}.{}. Make sure your toolbox is up to date.".format(
            device_xml_major_version, device_xml_minor_version))

    # Conversion de champs et écriture
    # conversion en valeurs réelles
    if device_xml_major_version >= 10:
        # - conversion d'unités de microsecondes vers unités de 10 ns
        header["ExposureTime"] = int(header["ExposureTime"] * 100)
        # - conversion d'unités de Hz vers unités de mHz
        header["AcquisitionFrameRate"] = int(header["AcquisitionFrameRate"] * 1000)

    if 'HFOV' in header:
        # - conversion d'unités de degrés vers unités de 0.1 degrés
        header["HFOV"] = int(header["HFOV"] * 10)

    if 'VFOV' in header:
        # - conversion d'unités de degrés vers unités de 0.1 degrés
        header["VFOV"] = int(header["VFOV"] * 10)

    # conversion d'unités standard de température
    liste_temperatures = []
    champs_h = list(header.keys())
    for key in champs_h:
        if key.startswith("Temperature"):
            liste_temperatures.append(key)

    if len(liste_temperatures) == 0:
        for key in champs_h:
            if key.startswith("DeviceTemperature"):
                liste_temperatures.append(key)

    for i in range(0, len(liste_temperatures)):
        kelvin = "TemperatureSensor" in liste_temperatures[i]
        if kelvin:
            # conversion d'unités de kelvins vers unités de 0.01 degrés Celsius
            header[liste_temperatures[i]] = np.int16((header[liste_temperatures[i]] - 273.15) * 100)
        else:
            # conversion d'unités de degrés Celsius vers unités de 0.01 degrés Celsius
            header[liste_temperatures[i]] = np.int16(header[liste_temperatures[i]] * 100)

    # écriture des champs de l'en-tête
    write_header(fid, header)
