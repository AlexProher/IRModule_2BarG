

def convert_header(header):
    """
    Convert a header composed of a dictionnary of arrays to a list of dictionnaries (one for each frame)

        INPUT
            header : header of a .hcc sequence as extracted by the function read_ircam (a dictionnary of arrays)

        OUTPUT
            header_converted : The same header written as a list of dictionnaries. Each dictionnary is the header of a
            frame in the sequence .hcc

    Copyright Telops 2019
    Author : BTU
    """
    header_converted = []
    header_keys_laid = header.keys()
    header_keys = []
    for key in header_keys_laid:
        header_keys.append(key)
    nb_frames = header[header_keys[0]].shape[0]
    for frame in range(0, nb_frames):
        frame_dict = {}
        for key in header_keys:
            frame_dict[key] = header[key][frame]
        header_converted.append(frame_dict)

    return header_converted
