from math import pi


def define_constants(ensemble='rien'):
    """
    Return structures of physical constants and conversion factors between units
        constants, conversions = defineConstants

        Example: build a dictionary FC with values of all fundamental constants
            C = defineConstants

        All constants are in MKSA units

        How to use:
        This function should be called when constants or conversion factors are needed.

    Reference: http://physics.nist.gov/cuu/Constants/

    Copyright Telops 2015
    """

    # Ensemble de constantes fondamentales

    # ensemble par défaut
    if ensemble == 'rien':
        ensemble = '2014 CODATA values'

    if ensemble == '2014 CODATA values':
        # Fundamental Physical Constants - CODATA Internationally recommended values - 2014
        # variable de sortie constants est un dictionnaire de dictionnaires
        # initialisation des dictionnaires
        atomic_mass = {}
        avogadro = {}
        boltzmann = {}
        elementary_charge = {}
        electron_mass = {}
        planck = {}
        stefan_blotzmann_constant = {}

        constants = {"atomic_mass": atomic_mass,   # variable de retour, dictionnaire parent
                     "avogadro": avogadro,
                     "boltzmann": boltzmann,
                     "elementary_charge": elementary_charge,
                     "electron_mass": electron_mass,
                     "planck": planck,
                     "stefan_boltzmann_constant": stefan_blotzmann_constant}

        # atomic mass constant [kg]
        atomic_mass["val"] = 1.660539040e-27
        atomic_mass["std"] = 0.000000020e-27
        atomic_mass["units"] = 'kg'
        atomic_mass["symbol"] = "m_u"
        atomic_mass["name"] = 'atomic mass constant'

        # Avogadro constant [mol^-1]
        avogadro["val"] = 6.022140857e+23
        avogadro["std"] = 0.000000074e+23
        avogadro["units"] = 'mol^{-1}'
        avogadro["symbol"] = 'N_A'
        avogadro["name"] = 'Avogadro constant'

        # Boltzmann constant [J/K]
        boltzmann["val"] = 1.38064852e-23
        boltzmann["std"] = 0.00000079e-23
        boltzmann["units"] = 'J/K'
        boltzmann["symbol"] = 'k'
        boltzmann["name"] = 'Boltzmann constant'

        # elementary charge [C]
        elementary_charge["val"] = 1.6021766208e-19
        elementary_charge["std"] = 0.0000000098e-19
        elementary_charge["units"] = 'C'
        elementary_charge["symbol"] = 'e'
        elementary_charge["name"] = 'elementary charge'

        # electron mass [kg]
        electron_mass["val"] = 9.10938356e-31
        electron_mass["std"] = 0.00000011e-31
        electron_mass["units"] = 'kg'
        electron_mass["symbol"] = 'm_e'
        electron_mass["name"] = 'electron mass'

        # Planck constant [J.s]
        planck["val"] = 6.626070040e-34
        planck["std"] = 0.000000081e-34
        planck["units"] = 'J.s'
        planck["symbol"] = 'h'
        planck["name"] = 'Planck constant'

        # Stefan-Boltzmann constant [W/(m^2 K^4)]
        stefan_blotzmann_constant["val"] = 5.670367e-8
        stefan_blotzmann_constant["std"] = 0.000013e-8
        stefan_blotzmann_constant["units"] = 'W/(m^{2} K^{4})'
        stefan_blotzmann_constant["symbol"] = 'sigma'
        stefan_blotzmann_constant["name"] = 'Stefan-Boltzmann constant'

    elif ensemble == '2010 CODATA values':
        # Fundamental Physical Constants - CODATA Internationally recommenced values - 2010
        # variable de sortie constants est un dictionnaire de dictionnaires
        atomic_mass = {}
        avogadro = {}
        boltzmann = {}
        elementary_charge = {}
        electron_mass = {}
        planck = {}
        stefan_blotzmann_constant = {}

        constants = {"atomic_mass": atomic_mass,   # variable de sortie, dictionnaire parent
                     "avogadro": avogadro,
                     "boltzmann": boltzmann,
                     "elementary_charge": elementary_charge,
                     "electron_mass": electron_mass,
                     "planck": planck,
                     "stefan_boltzmann_constant": stefan_blotzmann_constant}

        # atomic mass constant [kg]
        atomic_mass["val"] = 1.660538921e-27
        atomic_mass["std"] = 0.000000073e-27
        atomic_mass["units"] = 'kg'
        atomic_mass["symbol"] = "m_u"
        atomic_mass["name"] = 'atomic mass constant'

        # Avogadro constant [mol^-1]
        avogadro["val"] = 6.02214129e+23
        avogadro["std"] = 0.00000027e+23
        avogadro["units"] = 'mol^{-1}'
        avogadro["symbol"] = 'N_A'
        avogadro["name"] = 'Avogadro constant'

        # Boltzmann constant [J/K]
        boltzmann["val"] = 1.3806488e-23
        boltzmann["std"] = 0.0000013e-23
        boltzmann["units"] = 'J/K'
        boltzmann["symbol"] = 'k'
        boltzmann["name"] = 'Boltzmann constant'

        # elementary charge [C]
        elementary_charge["val"] = 1.602176565e-19
        elementary_charge["std"] = 0.000000035e-19
        elementary_charge["units"] = 'C'
        elementary_charge["symbol"] = 'e'
        elementary_charge["name"] = 'elementary charge'

        # electron mass [kg]
        electron_mass["val"] = 9.10938291e-31
        electron_mass["std"] = 0.00000040e-31
        electron_mass["units"] = 'kg'
        electron_mass["symbol"] = 'm_e'
        electron_mass["name"] = 'electron mass'

        # Planck constant [J.s]
        planck["val"] = 6.62606957e-34
        planck["std"] = 0.00000029e-34
        planck["units"] = 'J.s'
        planck["symbol"] = 'h'
        planck["name"] = 'Planck constant'

        # Stefan-Boltzmann constant [W/(m^2 K^4)]
        stefan_blotzmann_constant["val"] = 5.670373e-8
        stefan_blotzmann_constant["std"] = 0.000021e-8
        stefan_blotzmann_constant["units"] = 'W/(m^{2} K^{4})'
        stefan_blotzmann_constant["symbol"] = 'sigma'
        stefan_blotzmann_constant["name"] = 'Stefan-Boltzmann constant'

    else:
        raise UserWarning("defineConstants:ensemble_non_supporte"
                          "\nThe requested dataset, {}, is not available.".format(ensemble))

    # magnetic constant [N/A^{2}]
    constants["magnetic_constant"] = {"val": pi * 4e-7,
                                      "std": 0,
                                      "units": 'N/A^{2}',
                                      "symbol": 'mu_0',
                                      "name": 'magnetic_constant'}

    # speed of light [m/s]
    constants["speed_of_light"] = {"val": 299792458,
                                   "std": 0,
                                   'units': 'm/s',
                                   'symbol': 'c',
                                   'name': 'speed of light in vacuum'}

    # electric constant [F/m]
    constants["electric_constant"] = {"val": 1 / (constants["magnetic_constant"]["val"] *
                                                  constants["speed_of_light"]["val"]**2),
                                      "std": 0,
                                      "units": 'F/m',
                                      'symbol': "epsilon_0",
                                      'name': 'electric constant'}

    # Conversions

    conversions = {"kg_per_pound": 0.45359237,   # [kg/lb]
                   "pound_per_kg": 1/45359237,   # [lb/kg]
                   "sec_per_hour": 60 * 60,   # [s/h]
                   "hour_per_sec": 1/3600}   # [h/s]

    return constants, conversions
