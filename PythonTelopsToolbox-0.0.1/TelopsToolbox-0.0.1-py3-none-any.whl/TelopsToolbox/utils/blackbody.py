from TelopsToolbox.utils.defineConstants import define_constants
import numpy as np


def blackbody(sigma, T=273.15):
    """
    Radiance of a black body.
        x = blackbody(sigma, T) gives the radiance [watt/m^2 cm^-1 sr] of a black body at wavenumber SIGMA [cm^-1] and
        temperature T [K].

        The size of X is the common size of the input arguments. A scalar input functions as a constant matrix of the
        same size as the other inputs.

        INPUTS
            sigma       :       spectral grid, Nx1 numpy array.
                                Units are the same as 'unit' input parameter. (defaults to 'cm^-1')
            T           :       blackbody temperature, 1xM row vector (list or numpy array), [K].

        OUTPUTS
            x           :       MxN vector in radiance units according to that of the spectral grid.

        EXAMPLES:
            from TelopsToolbox.utils.blackbody import blackbody
            blackbody(np.array([950, 975, 1000, 1050]), [290, 400])
            blackbody(np.array([950, 975, 1000]),np.array([290, 400]))
            blackbody(np.array([950, 975, 1000]))
        Default values for T is 273.15.

    """

    phys_constants, conversion = define_constants()

    c = phys_constants["speed_of_light"]["val"]   # [m/s]
    h = phys_constants["planck"]["val"]           # [J s]
    kB = phys_constants["boltzmann"]["val"]       # [J/K]

    if isinstance(T, float):
        len_T = 1
    else:
        # the user can provide a list or a numpy array
        len_T = len(T)

    # Compute the radiance function for the intermediate values
    #       - convert sigma to m^-1
    c1 = 200 * h * c**2 * 100 * 100 * 100
    c2 = 100 * np.divide(h * c, kB * np.reshape(T, (1, len_T)))
    c2 = c2[0]   # to vector
    idx = sigma > 0
    if np.all(idx):
        if len_T == 1:
            x = np.divide(c1 * sigma * sigma * sigma, np.exp(c2 * sigma) - 1)
        else:
            x = np.zeros((len_T, sigma.shape[0]))
            for i in range(len_T):
                x[i, :] = np.divide(c1 * sigma * sigma * sigma, np.exp(c2[i] * sigma) - 1)
    else:
        if len_T == 1:
            # Allocate space for x.
            #       - put in the correct values when T is 0
            #       - put in the correct values when SIGMA is 0
            x = np.zeros(sigma.shape)
            # compute Planck function
            sigma_idx = sigma[idx]  # suppress the elements < 0
            x[idx] = np.divide(c1 * sigma_idx * sigma_idx * sigma_idx, np.exp(c2 * sigma_idx) - 1)
            # Return NaN if the arguments are outside their respective limits
            # x[sigma < 0 or T < 0]
            x[np.logical_or(sigma < 0, T < 0)] = np.nan
        else:
            x = np.zeros((len_T, sigma.shape[0]))
            sigma_idx = sigma[idx]
            for i in range(len_T):
                x[i, idx] = np.divide(c1 * sigma_idx * sigma_idx * sigma_idx, np.exp(c2[i] * sigma_idx) - 1)
                x[i, np.logical_or(sigma < 0, T < 0)] = np.nan

    return x
